# DR TV · Glass Edition (Fire Stick HD) — V3

An independent, TV-remote-friendly **Android IPTV client** inspired by the Sky Glass navigation style, featuring the **Sky logo** for a personal-use visual treatment. This is **not** Sky OS, a Sky app, or affiliated with Sky.

## What works in the source

- Xtream Codes login: server DNS/URL, username, password.
- **Remember me:** device-side login details protected with the Android Keystore (AES-GCM). Clearing the app's data or logging out clears remembered credentials.
- Live TV, VOD movies, series/episodes from supported provider API responses.
- Remote/D-pad focus, horizontal poster rails, category browsing, 48-item incremental display, full-screen playback controls.
- Short EPG programme information when supplied by the provider.
- My List (favourites), recently played and resume point for movies/episodes.
- Adaptive stream playback via Media3 ExoPlayer, with `.m3u8` fallback on live-stream errors.
- Dark blue/purple interface and Sky brand image fetched from [Sky's public brand page](https://skygroup.sky/en-gb/press/assets/logos) at runtime. If its asset is unavailable, the app displays a simple `sky` text fallback.

## Build in Android Studio (Windows or Mac)

1. Extract `DRTV_SkyStyle_FireStick.zip`.
2. Open **Android Studio** and choose **Open** (not New Project). Pick the extracted `DRTV_SkyStyle_FireStick` directory.
3. Allow Gradle, Android SDK **35**, and required libraries to download. Java 17+ is required.
4. From the menu, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The **debug APK** will appear at `app/build/outputs/apk/debug/app-debug.apk`. Use that APK for your own Fire Stick.
6. On Fire Stick HD, enable developer options and ADB debugging if using ADB. Install with `adb install -r app-debug.apk`, or transfer the APK using a trusted file transfer method and open it with an installer.
7. Open **DR TV · Glass Edition**, enter your provider's DNS, username and password, then select Remember Me if desired.

**Important:** This ZIP is a *source code project*, not an APK. This environment does not have the Android SDK/Gradle distribution to produce or test a signed APK. The code has been reviewed for obvious issues but must still be built and tested on the device. IPTV providers differ: some use proprietary endpoints, DRM or unsupported codecs that a generic Xtream client cannot access. No content or subscriptions are included.

## Notes about security and branding

- Logins are encrypted at rest using Android Keystore; credentials appear in API and stream requests because that is how Xtream URLs work. Choose HTTPS DNS if your provider offers it, because HTTP is not encrypted in transit.
- Only connect to services and streams you have permission to use.
- This is for personal experimentation. Sky's name and logo are trademarks. Do not distribute it as an official Sky app, impersonate Sky, or commercially market it with their branding without authorisation.
- The official logo image is network-fetched rather than embedded. The rest of the interface renders offline, but channel/movie content requires your IPTV provider.

## Troubleshooting

- **'App not installed'**: uninstall any older app with the same package ID if signed by a different key, then install again. This project's `applicationId` is `com.drtv.glass`; previous versions might have a different ID. Confirm the APK built successfully before transferring it.
- **Login fails**: enter the full DNS (e.g. `http://example.com:8080`) **without** `/player_api.php`, and test a valid account supplied by your provider.
- **Black player screen**: a provider stream may be offline, HTTP-blocked, codec-unsupported or use DRM. The player automatically retries a live channel as HLS once.
- **Movie doesn't click**: all items have an explicit card click action. If details open but playback fails, verify the provider exposes a valid `container_extension` and accessible stream.
- **Oversized category**: the client refuses JSON responses over 24 MiB rather than exhausting Fire Stick RAM. Split large libraries into provider-side categories where possible.

## Technical structure

- `ui/LoginActivity`: first-open/login flow.
- `ui/HomeActivity`: Sky-style home, category pages and local lists.
- `ui/DetailsActivity`: film detail, series episodes, channel EPG.
- `ui/PlayerActivity`: ExoPlayer playback, HLS fallback, resume.
- `api/XtreamClient`: asynchronous HTTP endpoints with limits and timeouts.
- `data/Session`: Android Keystore encrypted login.
- `data/Library`: favourites and recent locally stored.
- `ui/ImageLoader`: memory-bounded asynchronous artwork loader.

`gradlew` and `gradlew.bat` use a small Java 17 bootstrapper bundled as `gradle/wrapper/gradle-wrapper.jar`, generated from the included `gradle/wrapper-src/` source. This bootstrapper downloads Gradle 8.11.1 as specified in `gradle-wrapper.properties`.
