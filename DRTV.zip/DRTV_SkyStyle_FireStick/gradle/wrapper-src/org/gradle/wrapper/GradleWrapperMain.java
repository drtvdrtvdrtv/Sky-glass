package org.gradle.wrapper;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small offline-generated bootstrapper. It downloads the distribution specified by gradle-wrapper.properties. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path project=Paths.get(System.getProperty("user.dir"));
        Path propsFile=project.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties p=new Properties();
        try(InputStream in=Files.newInputStream(propsFile)) { p.load(in); }
        String distribution=p.getProperty("distributionUrl");
        String zipName=distribution.substring(distribution.lastIndexOf('/')+1);
        String dirName=zipName.replace(".zip","");
        String userHome=System.getenv("GRADLE_USER_HOME");
        Path cache=Paths.get(userHome==null || userHome.isEmpty() ?
                System.getProperty("user.home")+"/.gradle" : userHome).resolve("wrapper/dists/drtv-"+dirName);
        Path gradleHome=cache.resolve(dirName.replace("-bin", "").replace("-all", ""));
        Path gradleScript=gradleHome.resolve("bin/gradle");
        Path gradleBat=gradleHome.resolve("bin/gradle.bat");
        if(!Files.exists(gradleScript) && !Files.exists(gradleBat)) {
            Files.createDirectories(cache);
            Path zip=cache.resolve(zipName);
            if(!Files.exists(zip)) {
                System.out.println("Downloading Gradle "+distribution+" ...");
                Path temp=cache.resolve(zipName+".part");
                try(InputStream in=URI.create(distribution).toURL().openStream()) {
                    Files.copy(in,temp,StandardCopyOption.REPLACE_EXISTING);
                }
                Files.move(temp,zip,StandardCopyOption.REPLACE_EXISTING);
            }
            try(ZipInputStream zis=new ZipInputStream(Files.newInputStream(zip))) {
                ZipEntry e;
                while((e=zis.getNextEntry())!=null) {
                    Path out=cache.resolve(e.getName()).normalize();
                    if(!out.startsWith(cache)) throw new SecurityException("Unsafe ZIP entry");
                    if(e.isDirectory()) Files.createDirectories(out);
                    else {
                        Files.createDirectories(out.getParent());
                        Files.copy(zis,out,StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
        }
        boolean windows=System.getProperty("os.name").toLowerCase().contains("win");
        List<String> command=new ArrayList<>();
        if(windows) {command.add("cmd.exe");command.add("/c");command.add(gradleBat.toString());}
        else {gradleScript.toFile().setExecutable(true);command.add(gradleScript.toString());}
        for(String arg:args) command.add(arg);
        Process child=new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(child.waitFor());
    }
}
