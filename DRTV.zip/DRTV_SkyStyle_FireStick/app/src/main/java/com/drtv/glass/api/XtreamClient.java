package com.drtv.glass.api;

import android.os.Handler;
import android.os.Looper;
import com.drtv.glass.data.MediaEntry;
import com.drtv.glass.data.Session;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** General-purpose Xtream Codes API client for streams you are authorised to access. */
public final class XtreamClient {
    private static final ExecutorService IO = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_RESPONSE_BYTES = 24 * 1024 * 1024;
    private XtreamClient() {}
    public interface Callback<T> { void done(T result, String error); }

    private static String enc(String value) {
        try { return URLEncoder.encode(value, "UTF-8").replace("+", "%20"); }
        catch (Exception e) { return ""; }
    }
    public static String normalizeHost(String raw) {
        String host = raw == null ? "" : raw.trim();
        if (!host.matches("(?i)^https?://.*")) host = "http://"+host;
        while(host.endsWith("/")) host = host.substring(0,host.length()-1);
        if (host.endsWith("/c")) host = host.substring(0,host.length()-2);
        return host;
    }
    private static JSONObject authInfo(String host, String username, String password) throws Exception {
        String url = host + "/player_api.php?username=" + enc(username) + "&password=" + enc(password);
        Object response = fetch(url);
        if (!(response instanceof JSONObject)) throw new Exception("Invalid server response");
        return (JSONObject) response;
    }
    private static Object fetch(String url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(18000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "DRTV-Glass/3.0 AndroidTV");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new Exception("Server returned HTTP " + status);
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n, size = 0;
                while ((n=input.read(buffer)) != -1) {
                    size+=n;
                    if (size > MAX_RESPONSE_BYTES) throw new Exception("This category is too large for this device");
                    output.write(buffer,0,n);
                }
                String data = output.toString("UTF-8").trim();
                if (data.startsWith("[")) return new JSONArray(data);
                if (data.startsWith("{")) return new JSONObject(data);
                throw new Exception("Provider returned an invalid response");
            }
        } finally { connection.disconnect(); }
    }
    private static String apiUrl(String action, String extra) {
        return Session.host + "/player_api.php?username=" + enc(Session.username) +
                "&password=" + enc(Session.password) + "&action=" + enc(action) + (extra==null ? "" : extra);
    }
    private static String safeError(Exception e) {
        String msg=e.getMessage();
        if (msg==null || msg.isEmpty()) return "Connection failed. Check your DNS and internet connection.";
        // URLs may contain API credentials. Never display exception text that includes a URL.
        if (msg.contains("http:") || msg.contains("https:")) return "Could not reach the provider. Check your DNS or internet.";
        return msg.length()>140 ? msg.substring(0,140) : msg;
    }
    private static <T> void dispatch(Callback<T> callback, T result, String error) {
        MAIN.post(() -> callback.done(result,error));
    }
    public static void login(String dns, String user, String pass, Callback<String> callback) {
        IO.execute(() -> {
            try {
                String host = normalizeHost(dns);
                URL parsed = new URL(host);
                if (parsed.getHost().isEmpty() || user.isEmpty() || pass.isEmpty()) {
                    dispatch(callback,null,"Enter a valid DNS, username and password."); return;
                }
                JSONObject json=authInfo(host,user,pass);
                JSONObject info=json.optJSONObject("user_info");
                if (info==null) { dispatch(callback,null,"Your provider did not return account information."); return; }
                String auth=info.optString("auth", "0");
                String status=info.optString("status", "Active");
                if (!("1".equals(auth) || "true".equalsIgnoreCase(auth)) ||
                        !"Active".equalsIgnoreCase(status)) {
                    dispatch(callback,null,"Login rejected or subscription inactive."); return;
                }
                dispatch(callback,host,null);
            } catch (Exception e) { dispatch(callback,null,safeError(e)); }
        });
    }
    public static void categories(String type, Callback<JSONArray> cb) {
        String action = MediaEntry.LIVE.equals(type) ? "get_live_categories" :
                MediaEntry.MOVIE.equals(type) ? "get_vod_categories" : "get_series_categories";
        requestArray(action,"",cb);
    }
    public static void entries(String type, String category, Callback<JSONArray> cb) {
        String action=MediaEntry.LIVE.equals(type) ? "get_live_streams" :
                MediaEntry.MOVIE.equals(type) ? "get_vod_streams" : "get_series";
        String extra = category==null || category.isEmpty() ? "" : "&category_id=" + enc(category);
        requestArray(action,extra,cb);
    }
    public static void shortEpg(String streamId, Callback<JSONArray> cb) {
        request("get_short_epg","&stream_id="+enc(streamId)+"&limit=12",(res,error) -> {
            if (error!=null) { cb.done(null,error); return; }
            if (!(res instanceof JSONObject)) { cb.done(new JSONArray(),null); return; }
            cb.done(((JSONObject)res).optJSONArray("epg_listings") == null ? new JSONArray() :
                    ((JSONObject)res).optJSONArray("epg_listings"),null);
        });
    }
    public static void details(MediaEntry entry, Callback<JSONObject> cb) {
        if (MediaEntry.LIVE.equals(entry.type)) { dispatch(cb,new JSONObject(),null); return; }
        String action=MediaEntry.MOVIE.equals(entry.type) ? "get_vod_info" : "get_series_info";
        String idField=MediaEntry.MOVIE.equals(entry.type) ? "vod_id" : "series_id";
        request(action,"&"+idField+"="+enc(entry.id),(res,err) -> {
            if (err!=null) { cb.done(null,err); return; }
            cb.done(res instanceof JSONObject ? (JSONObject)res : new JSONObject(),null);
        });
    }
    private static void requestArray(String action, String extra, Callback<JSONArray> cb) {
        request(action,extra,(res,err)-> {
            if (err!=null) { cb.done(null,err); return; }
            if (res instanceof JSONArray) cb.done((JSONArray)res,null);
            else cb.done(new JSONArray(),null);
        });
    }
    private static void request(String action, String extra, Callback<Object> cb) {
        if (!Session.active()) { dispatch(cb,null,"Please sign in again."); return; }
        String url=apiUrl(action,extra);
        IO.execute(()-> { try { dispatch(cb,fetch(url),null); }
            catch(Exception e) { dispatch(cb,null,safeError(e)); } });
    }
    public static List<MediaEntry> page(JSONArray array, String type, int offset, int limit) {
        List<MediaEntry> result=new ArrayList<>();
        if (array==null) return result;
        for (int i=offset; i<array.length() && result.size()<limit; i++) {
            JSONObject j=array.optJSONObject(i);
            if (j==null) continue;
            MediaEntry entry=MediaEntry.fromApi(j,type);
            if (entry.id.isEmpty()) continue;
            if (MediaEntry.MOVIE.equals(type)) entry.image=j.optString("stream_icon", j.optString("cover", ""));
            result.add(entry);
        }
        return result;
    }
    public static String streamUrl(MediaEntry entry) {
        if (!Session.active()) return "";
        String ext=entry.extension==null ? "" : entry.extension.trim().replaceAll("[^a-zA-Z0-9]", "");
        if (ext.isEmpty()) ext="mp4";
        if (MediaEntry.LIVE.equals(entry.type)) ext="ts";
        String route=MediaEntry.LIVE.equals(entry.type) ? "live" : MediaEntry.SERIES.equals(entry.type) ? "series" : "movie";
        return Session.host + "/" + route + "/" + enc(Session.username) + "/" + enc(Session.password)
                + "/" + enc(entry.id) + "." + ext;
    }
    public static String liveHlsUrl(MediaEntry entry) {
        return Session.host + "/live/" + enc(Session.username) + "/" + enc(Session.password)
                + "/" + enc(entry.id) + ".m3u8";
    }
}
