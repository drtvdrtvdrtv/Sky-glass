package com.drtv.glass.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import com.drtv.glass.data.Library;
import com.drtv.glass.data.MediaEntry;
import com.drtv.glass.api.XtreamClient;
import org.json.JSONObject;

public final class PlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private MediaEntry item;
    private TextView info;
    private boolean hlsFallback=false;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try { item=MediaEntry.fromJson(new JSONObject(getIntent().getStringExtra("entry"))); }
        catch(Exception e) {finish();return;}
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xFF000000);setContentView(root);
        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(4500);
        root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout overlays=U.col(this);
        FrameLayout.LayoutParams panel=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);
        U.pad(overlays,this,24,16,24,12);
        root.addView(overlays,panel);
        info=U.text(this,item.title,17,true);info.setShadowLayer(4,1,1,0xFF000000);
        overlays.addView(info);
        player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException error) {
                if(MediaEntry.LIVE.equals(item.type) && !hlsFallback) {
                    hlsFallback=true;
                    info.setText("Trying alternative live stream format…");
                    play(XtreamClient.liveHlsUrl(item),true);
                    return;
                }
                info.setText("Playback failed · Press Back to return");
                Toast.makeText(PlayerActivity.this,"Stream unavailable or format not supported by this Fire Stick",Toast.LENGTH_LONG).show();
            }
        });
        String url=XtreamClient.streamUrl(item);
        if(url.isEmpty()) { info.setText("Session expired. Please sign in again.");return; }
        play(url,false);
    }
    private void play(String url,boolean hls) {
        MediaItem.Builder builder=new MediaItem.Builder().setUri(url);
        if(hls || url.toLowerCase().contains(".m3u8")) builder.setMimeType(MimeTypes.APPLICATION_M3U8);
        player.setMediaItem(builder.build());
        player.prepare();
        if(!MediaEntry.LIVE.equals(item.type) && item.resumeMs>10000) player.seekTo(item.resumeMs);
        player.play();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if(event.getAction()==KeyEvent.ACTION_DOWN &&
                (event.getKeyCode()==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || event.getKeyCode()==KeyEvent.KEYCODE_SPACE)) {
            if(player!=null) { if(player.isPlaying()) player.pause(); else player.play();return true; }
        }
        return super.dispatchKeyEvent(event);
    }
    @Override protected void onStop() {
        if(player!=null && item!=null) {
            long position=MediaEntry.LIVE.equals(item.type)?0:player.getCurrentPosition();
            Library.watched(this,item,position);
        }
        super.onStop();
    }
    @Override protected void onDestroy() {
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
