package com.drtv.glass.ui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageLoader {
    // Official Sky press image; only used for the user's local, personal app design.
    public static final String SKY_LOGO_URL = "https://static.skyassets.com/contentstack/assets/blt4b099fa9cc3801a6/blte86680a590cb0c71/68b59d2478db10383ff4b114/Sky-glow-tile.jpg?downsize=320%2C640%3A%2A&output-format=jpg";
    private static final ExecutorService POOL=Executors.newFixedThreadPool(4);
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static final LruCache<String,Bitmap> CACHE=new LruCache<String,Bitmap>(12*1024*1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private ImageLoader() {}
    public static void load(ImageView view, String url) {
        if (url==null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
        view.setTag(url);
        Bitmap cached=CACHE.get(url);
        if (cached!=null) { view.setImageBitmap(cached); return; }
        POOL.execute(()-> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(6000); c.setReadTimeout(8000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 AndroidTV");
                try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                    byte[] buf=new byte[8192]; int n,total=0;
                    while((n=in.read(buf))!=-1) {
                        total+=n;
                        if (total>2_000_000) return;
                        out.write(buf,0,n);
                    }
                    byte[] raw=out.toByteArray();
                    BitmapFactory.Options opts=new BitmapFactory.Options();
                    opts.inJustDecodeBounds=true;
                    BitmapFactory.decodeByteArray(raw,0,raw.length,opts);
                    opts.inSampleSize=1;
                    while(opts.outWidth/opts.inSampleSize>640 || opts.outHeight/opts.inSampleSize>480) opts.inSampleSize*=2;
                    opts.inJustDecodeBounds=false;
                    Bitmap bitmap=BitmapFactory.decodeByteArray(raw,0,raw.length,opts);
                    if(bitmap!=null) {
                        CACHE.put(url,bitmap);
                        MAIN.post(()-> { if (url.equals(view.getTag())) view.setImageBitmap(bitmap); });
                    }
                }
            } catch(Exception ignored) {} finally { if(c!=null)c.disconnect(); }
        });
    }
}
