package com.drtv.glass.data;

import org.json.JSONException;
import org.json.JSONObject;

public final class MediaEntry {
    public static final String LIVE = "live", MOVIE = "movie", SERIES = "series";
    public String id, type, title, image, categoryId, extension;
    public String description = "", rating = "", year = "";
    public long resumeMs = 0;
    public MediaEntry(String id, String type, String title, String image, String categoryId, String extension) {
        this.id=id; this.type=type; this.title=title; this.image=image; this.categoryId=categoryId; this.extension=extension;
    }
    public static MediaEntry fromApi(JSONObject obj, String type) {
        String idField = LIVE.equals(type) ? "stream_id" : SERIES.equals(type) ? "series_id" : "stream_id";
        return new MediaEntry(obj.optString(idField, ""), type,
                obj.optString("name", "Untitled"),
                obj.optString(SERIES.equals(type) ? "cover" : "stream_icon", ""),
                obj.optString("category_id", ""), obj.optString("container_extension", "mp4"));
    }
    public JSONObject toJson() {
        JSONObject obj = new JSONObject();
        try { obj.put("id",id); obj.put("type",type); obj.put("title",title); obj.put("image",image);
            obj.put("cat",categoryId); obj.put("ext",extension); obj.put("resume",resumeMs); } catch (JSONException ignored) {}
        return obj;
    }
    public static MediaEntry fromJson(JSONObject j) {
        MediaEntry item = new MediaEntry(j.optString("id"),j.optString("type"),j.optString("title"),
                j.optString("image"),j.optString("cat"),j.optString("ext", "mp4"));
        item.resumeMs = j.optLong("resume", 0); return item;
    }
    public String uniqueKey() { return type + ":" + id; }
}
