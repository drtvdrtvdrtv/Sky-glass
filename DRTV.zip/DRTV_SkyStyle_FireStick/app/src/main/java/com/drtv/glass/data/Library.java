package com.drtv.glass.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class Library {
    private static final String PREF = "drtv_library_v3";
    private Library() {}
    public static List<MediaEntry> get(Context c, String key) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        List<MediaEntry> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(p.getString(key, "[]"));
            for (int i=0;i<array.length();i++) result.add(MediaEntry.fromJson(array.getJSONObject(i)));
        } catch (Exception ignored) {}
        return result;
    }
    private static void put(Context c, String key, List<MediaEntry> entries) {
        JSONArray arr = new JSONArray();
        for (MediaEntry item : entries) arr.put(item.toJson());
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(key, arr.toString()).apply();
    }
    public static boolean isFavourite(Context c, MediaEntry item) {
        for (MediaEntry v : get(c, "favourites")) if (v.uniqueKey().equals(item.uniqueKey())) return true;
        return false;
    }
    public static boolean toggleFavourite(Context c, MediaEntry item) {
        List<MediaEntry> entries = get(c,"favourites");
        boolean removed = false;
        for (int i=entries.size()-1;i>=0;i--) {
            if (entries.get(i).uniqueKey().equals(item.uniqueKey())) { entries.remove(i); removed=true; }
        }
        if (!removed) entries.add(0,item);
        put(c,"favourites",entries);
        return !removed;
    }
    public static void watched(Context c, MediaEntry item, long positionMs) {
        if (item == null || item.id == null || item.id.isEmpty()) return;
        List<MediaEntry> entries = get(c,"recent");
        for (int i=entries.size()-1;i>=0;i--) {
            if (entries.get(i).uniqueKey().equals(item.uniqueKey())) entries.remove(i);
        }
        item.resumeMs = positionMs;
        entries.add(0,item);
        while(entries.size()>24) entries.remove(entries.size()-1);
        put(c,"recent",entries);
    }
}
