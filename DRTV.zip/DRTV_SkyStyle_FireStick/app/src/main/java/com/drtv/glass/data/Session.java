package com.drtv.glass.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class Session {
    private static final String PREF = "drtv_settings_v3";
    private static final String KEY_ALIAS = "drtv_glass_private_login_v3";
    public static String host = "", username = "", password = "";
    private Session() {}

    public static boolean active() { return !host.isEmpty() && !username.isEmpty() && !password.isEmpty(); }
    public static void use(String h, String u, String p) { host = h; username = u; password = p; }

    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey found = (SecretKey) store.getKey(KEY_ALIAS, null);
        if (found != null) return found;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build());
        return generator.generateKey();
    }
    private static String encrypt(String plain) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV(), enc = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + "." + Base64.encodeToString(enc, Base64.NO_WRAP);
    }
    private static String decrypt(String data) throws Exception {
        String[] pieces = data.split("\\.");
        if (pieces.length != 2) throw new IllegalArgumentException("Bad storage");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(pieces[0], Base64.DEFAULT)));
        return new String(cipher.doFinal(Base64.decode(pieces[1], Base64.DEFAULT)), StandardCharsets.UTF_8);
    }
    public static void save(Context c, boolean remember) throws Exception {
        SharedPreferences.Editor e = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit();
        if (remember) {
            e.putString("host", encrypt(host));
            e.putString("user", encrypt(username));
            e.putString("pass", encrypt(password));
            e.putBoolean("remember", true);
        } else {
            e.remove("host").remove("user").remove("pass").putBoolean("remember", false);
        }
        e.apply();
    }
    public static boolean restore(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("remember", false)) return false;
        try {
            use(decrypt(p.getString("host", "")), decrypt(p.getString("user", "")), decrypt(p.getString("pass", "")));
            return active();
        } catch (Exception ignored) { clear(c); return false; }
    }
    public static void clear(Context c) {
        host = username = password = "";
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .remove("host").remove("user").remove("pass").putBoolean("remember", false).apply();
    }
}
