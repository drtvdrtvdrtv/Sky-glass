package com.drtv.glass.ui;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.drtv.glass.R;
import com.drtv.glass.data.MediaEntry;

/** TV-first, D-pad focusable, programmatic layouts (no Compose runtime required). */
public final class U {
    public static final int WHITE=Color.WHITE, MUTED=0xFFBBC4E2, LAVENDER=0xFFC4B4FF;
    private U() {}
    public static int dp(Context c,float n) { return (int)(n*c.getResources().getDisplayMetrics().density+0.5f); }
    public static GradientDrawable rounded(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    public static LinearLayout col(Context c) { LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l; }
    public static LinearLayout row(Context c) { LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    public static TextView text(Context c,String s,int sp,boolean bold) {
        TextView t=new TextView(c);t.setText(s);t.setTextColor(WHITE);t.setTextSize(sp);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    public static LinearLayout.LayoutParams lp(int w,int h,Context c) {
        return new LinearLayout.LayoutParams(w<0?w:dp(c,w),h<0?h:dp(c,h));
    }
    public static void pad(View v,Context c,int l,int top,int r,int bottom) {
        v.setPadding(dp(c,l),dp(c,top),dp(c,r),dp(c,bottom));
    }
    public static void focus(View v,Context c,int normal) {
        v.setFocusable(true);v.setClickable(true);
        v.setOnFocusChangeListener((view,has)-> {
            view.animate().scaleX(has?1.045f:1f).scaleY(has?1.045f:1f).setDuration(110).start();
            GradientDrawable bg=rounded(has?0xFF47457A:normal,dp(c,11));
            bg.setStroke(dp(c,has?2:1),has?0xFFFFFFFF:0x334F587A);
            view.setBackground(bg);
            view.setElevation(dp(c,has?8:0));
        });
        v.setBackground(rounded(normal,dp(c,11)));
    }
    public static Button button(Context c,String label, Runnable action) {
        Button b=new Button(c);b.setAllCaps(false);b.setText(label);b.setTextColor(WHITE);
        b.setTextSize(14);b.setMinHeight(dp(c,42));b.setMinWidth(dp(c,105));
        b.setBackgroundTintList(null);focus(b,c,0x60383C68);
        b.setOnClickListener(view->action.run());return b;
    }
    public static View skyLogo(Context c,int width,int height) {
        FrameLayout wrap=new FrameLayout(c);
        wrap.setLayoutParams(lp(width,height,c));
        wrap.setBackground(rounded(0xFF1C216E,dp(c,10)));
        // Fallback remains available even when the official image cannot load.
        TextView text=text(c,"sky",31,true);text.setTextColor(Color.WHITE);
        text.setGravity(Gravity.CENTER);
        text.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD_ITALIC));
        wrap.addView(text,new FrameLayout.LayoutParams(-1,-1));
        ImageView img=new ImageView(c);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wrap.addView(img,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.load(img,ImageLoader.SKY_LOGO_URL);
        return wrap;
    }
    public static TextView label(Context c,String value) {
        TextView t=text(c,value,19,true);pad(t,c,0,14,0,10);return t;
    }
    public static View tile(Activity c,MediaEntry m,boolean landscape,Runnable open) {
        int width=landscape?208:148, height=landscape?124:190;
        LinearLayout card=col(c);
        LinearLayout.LayoutParams outer=lp(width+12,height+60,c);
        outer.setMargins(dp(c,2),0,dp(c,10),dp(c,6));card.setLayoutParams(outer);
        focus(card,c,0x66303961);
        ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackground(rounded(0xFF32365A,dp(c,10)));
        card.addView(image,lp(width+12,height,c));
        ImageLoader.load(image,m.image);
        TextView name=text(c,m.title,14,true);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pad(name,c,9,6,8,0);card.addView(name,lp(-1,50,c));
        card.setOnClickListener(v->open.run());
        return card;
    }
}
