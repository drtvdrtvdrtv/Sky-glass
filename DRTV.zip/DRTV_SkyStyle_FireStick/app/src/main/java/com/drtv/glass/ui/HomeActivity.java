package com.drtv.glass.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.drtv.glass.R;
import com.drtv.glass.api.XtreamClient;
import com.drtv.glass.data.Library;
import com.drtv.glass.data.MediaEntry;
import com.drtv.glass.data.Session;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

public final class HomeActivity extends Activity {
    private LinearLayout body,topNav;
    private String tab="Home";
    private int token=0;
    private JSONArray currentResults;
    private String currentType;
    private LinearLayout resultsBox;
    private int shown;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if(!Session.active()) { logout();return; }
        createShell();switchTab("Home");
    }
    @Override protected void onResume() {
        super.onResume();
        if(body!=null && (tab.equals("My List")||tab.equals("Continue"))) switchTab(tab);
    }
    private void createShell() {
        LinearLayout root=U.col(this);root.setBackgroundResource(R.drawable.bg_glass);
        setContentView(root);topNav=U.row(this);
        U.pad(topNav,this,33,10,30,6);
        root.addView(topNav,U.lp(-1,72,this));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body=U.col(this);U.pad(body,this,33,0,28,35);scroll.addView(body);
    }
    private void makeNav() {
        topNav.removeAllViews();topNav.addView(U.skyLogo(this,122,58));
        for(String title:new String[]{"Home","Live TV","Movies","Series","My List","Continue","Settings"}) {
            TextView item=U.text(this,title,15,tab.equals(title));
            item.setTextColor(tab.equals(title)?U.WHITE:U.MUTED);
            U.pad(item,this,15,8,15,8);
            U.focus(item,this,tab.equals(title)?0x88595988:0x00232948);
            item.setOnClickListener(v->switchTab(title));
            LinearLayout.LayoutParams p=U.lp(-2,44,this);p.setMargins(U.dp(this,6),0,0,0);
            topNav.addView(item,p);
        }
    }
    private void switchTab(String selected) {
        tab=selected;final int mine=++token;
        makeNav();body.removeAllViews();currentResults=null;
        switch(selected) {
            case "Home": home(mine);break;
            case "Live TV": browse(MediaEntry.LIVE,mine);break;
            case "Movies": browse(MediaEntry.MOVIE,mine);break;
            case "Series": browse(MediaEntry.SERIES,mine);break;
            case "My List": saved("My List","favourites");break;
            case "Continue": saved("Continue watching","recent");break;
            case "Settings": settings();break;
        }
    }
    private void title(String name,String subtitle) {
        TextView t=U.text(this,name,31,true);body.addView(t,U.lp(-1,54,this));
        TextView s=U.text(this,subtitle,14,false);s.setTextColor(U.MUTED);
        body.addView(s,U.lp(-1,28,this));
    }
    private void home(int mine) {
        LinearLayout hero=U.row(this);hero.setBackgroundResource(R.drawable.bg_hero);U.pad(hero,this,32,28,24,25);
        LinearLayout.LayoutParams hp=U.lp(-1,224,this);hp.setMargins(0,U.dp(this,14),0,U.dp(this,14));
        body.addView(hero,hp);
        LinearLayout content=U.col(this);hero.addView(content,new LinearLayout.LayoutParams(0,-1,1));
        TextView small=U.text(this,"YOUR ENTERTAINMENT, YOUR WAY",12,true);small.setTextColor(0xFFDDD2FF);
        content.addView(small,U.lp(-1,28,this));
        TextView big=U.text(this,"Everything you love. All in one place.",28,true);
        big.setMaxLines(2);content.addView(big,U.lp(-1,82,this));
        TextView below=U.text(this,"Live TV  •  Films  •  Box sets  •  Your favourites",15,false);
        below.setTextColor(U.MUTED);content.addView(below,U.lp(-1,36,this));
        LinearLayout actions=U.row(this);content.addView(actions,U.lp(-1,46,this));
        actions.addView(U.button(this,"Watch Live",()->switchTab("Live TV")),U.lp(145,44,this));
        LinearLayout.LayoutParams gap=U.lp(154,44,this);gap.setMargins(U.dp(this,12),0,0,0);
        actions.addView(U.button(this,"Explore Movies",()->switchTab("Movies")),gap);
        TextView artwork=U.text(this,"sky",78,true);artwork.setTextColor(0xCCFFFFFF);
        artwork.setGravity(Gravity.CENTER);artwork.setTypeface(android.graphics.Typeface.create("sans-serif-black",android.graphics.Typeface.BOLD_ITALIC));
        hero.addView(artwork,U.lp(205,-1,this));
        List<MediaEntry> recent=Library.get(this,"recent");if(!recent.isEmpty()) section("Continue watching",recent,true);
        List<MediaEntry> fav=Library.get(this,"favourites");if(!fav.isEmpty()) section("Your favourites",fav,true);
        showcase("Live TV",MediaEntry.LIVE,mine);
        showcase("Movies",MediaEntry.MOVIE,mine);
        showcase("Series",MediaEntry.SERIES,mine);
    }
    private void showcase(String sectionName,String type,int mine) {
        LinearLayout section=U.col(this);body.addView(section,U.lp(-1,-2,this));
        TextView headline=U.text(this,sectionName+"   ›",21,true);U.pad(headline,this,0,16,0,12);
        headline.setFocusable(true);headline.setOnClickListener(v->switchTab(sectionName));
        section.addView(headline,U.lp(-1,62,this));
        TextView loading=U.text(this,"Loading your selection…",13,false);loading.setTextColor(U.MUTED);
        section.addView(loading,U.lp(-1,42,this));
        XtreamClient.categories(type,(categories,error)->{
            if(mine!=token || isFinishing()) return;
            if(error!=null) { loading.setText("Unable to load: "+error);return; }
            String catId="";
            if(categories!=null && categories.length()>0) catId=categories.optJSONObject(0).optString("category_id","");
            XtreamClient.entries(type,catId,(entries,err)->{
                if(mine!=token || isFinishing()) return;
                section.removeView(loading);
                if(err!=null) { loading.setText(err);section.addView(loading);return; }
                List<MediaEntry> items=XtreamClient.page(entries,type,0,15);
                if(items.isEmpty()) { loading.setText("No items in this category");section.addView(loading);return; }
                section.addView(rail(items),U.lp(-1,type.equals(MediaEntry.LIVE)?210:282,this));
            });
        });
    }
    private void browse(String type,int mine) {
        currentType=type;
        String heading=MediaEntry.LIVE.equals(type)?"Live TV":MediaEntry.MOVIE.equals(type)?"Movies":"Series";
        title(heading,MediaEntry.LIVE.equals(type)?"Choose a channel to see what's on now":"Explore your provider's library");
        TextView label=U.label(this,"Categories");body.addView(label);
        HorizontalScrollView scroller=new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=U.row(this);chips.setPadding(0,0,U.dp(this,20),0);
        scroller.addView(chips);body.addView(scroller,U.lp(-1,56,this));
        TextView subtitle=U.label(this,"Select a category");body.addView(subtitle);
        resultsBox=U.col(this);body.addView(resultsBox,U.lp(-1,-2,this));
        TextView load=U.text(this,"Loading categories…",14,false);body.addView(load);
        XtreamClient.categories(type,(categories,error)->{
            if(mine!=token) return;
            body.removeView(load);
            if(error!=null) { message(resultsBox,error);return; }
            if(categories==null || categories.length()==0) {
                makeChip(chips,"All",()->loadCategory(type,"", "All",subtitle));
                loadCategory(type,"","All",subtitle);return;
            }
            for(int i=0;i<categories.length();i++) {
                JSONObject cat=categories.optJSONObject(i);if(cat==null)continue;
                String id=cat.optString("category_id","");String name=cat.optString("category_name","Other");
                makeChip(chips,name,()->loadCategory(type,id,name,subtitle));
                if(i==0) loadCategory(type,id,name,subtitle);
            }
        });
    }
    private void makeChip(LinearLayout row,String name,Runnable action) {
        android.widget.Button chip=U.button(this,name,action);
        LinearLayout.LayoutParams p=U.lp(-2,44,this);p.setMargins(0,0,U.dp(this,10),0);
        row.addView(chip,p);
    }
    private void loadCategory(String type,String id,String name,TextView subtitle) {
        final int mine=++token;
        subtitle.setText(name);
        resultsBox.removeAllViews();message(resultsBox,"Loading "+name+"…");
        XtreamClient.entries(type,id,(results,error)->{
            if(mine!=token || isFinishing())return;
            resultsBox.removeAllViews();
            if(error!=null) {message(resultsBox,error);return;}
            currentResults=results;shown=0;
            if(results==null || results.length()==0) {message(resultsBox,"Nothing found in this category.");return;}
            showMore(type);
        });
    }
    private void showMore(String type) {
        if(currentResults==null)return;
        // Remove the previous Load More row, if present.
        if(resultsBox.getChildCount()>0) {
            View last=resultsBox.getChildAt(resultsBox.getChildCount()-1);
            if("loadMore".equals(last.getTag()))resultsBox.removeView(last);
        }
        int count=Math.min(currentResults.length(),shown+48);
        LinearLayout currentRow=null;
        boolean landscape=MediaEntry.LIVE.equals(type);
        int columns=landscape?5:6;
        for(int i=shown;i<count;i++) {
            if((i-shown)%columns==0) {
                currentRow=U.row(this);currentRow.setGravity(Gravity.TOP);
                resultsBox.addView(currentRow,U.lp(-1,-2,this));
            }
            JSONObject raw=currentResults.optJSONObject(i);
            if(raw==null)continue;
            MediaEntry item=MediaEntry.fromApi(raw,type);
            if(item.id.isEmpty())continue;
            currentRow.addView(U.tile(this,item,landscape,()->open(item)));
        }
        shown=count;
        if(shown<currentResults.length()) {
            android.widget.Button more=U.button(this,"Show more  ("+shown+" / "+currentResults.length()+")",()->showMore(type));
            more.setTag("loadMore");
            LinearLayout.LayoutParams p=U.lp(270,52,this);p.setMargins(0,U.dp(this,17),0,U.dp(this,20));
            resultsBox.addView(more,p);
        }
    }
    private View rail(List<MediaEntry> items) {
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout rail=U.row(this);rail.setGravity(Gravity.TOP);
        boolean live=MediaEntry.LIVE.equals(items.get(0).type);
        for(MediaEntry item:items)rail.addView(U.tile(this,item,live,()->open(item)));
        scroll.addView(rail);return scroll;
    }
    private void section(String headline,List<MediaEntry> items,boolean mixed) {
        body.addView(U.label(this,headline));
        body.addView(rail(items),U.lp(-1,282,this));
    }
    private void saved(String heading,String key) {
        title(heading,"Saved on this Fire Stick");
        List<MediaEntry> items=Library.get(this,key);
        if(items.isEmpty()){message(body,"Nothing here yet. Browse something and add it to your list.");return;}
        section("Your selection",items,true);
    }
    private void settings() {
        title("Settings","DR TV · Glass Edition  •  Personal-use interface");
        body.addView(U.label(this,"Account"));
        TextView provider=U.text(this,"Provider: "+Session.host,14,false);provider.setTextColor(U.MUTED);
        body.addView(provider,U.lp(-1,44,this));
        body.addView(U.button(this,"Log out and forget login",this::logout),U.lp(280,49,this));
        TextView info=U.text(this,"Independent IPTV player for your authorised subscriptions. Not an official Sky product.",13,false);
        info.setTextColor(U.MUTED);U.pad(info,this,0,28,0,0);body.addView(info);
    }
    private void open(MediaEntry entry) {
        Intent intent=new Intent(this,DetailsActivity.class);
        intent.putExtra("entry",entry.toJson().toString());startActivity(intent);
    }
    private void message(LinearLayout target,String value) {
        TextView t=U.text(this,value,15,false);t.setTextColor(U.MUTED);
        target.addView(t,U.lp(-1,50,this));
    }
    private void logout() {
        Session.clear(this);startActivity(new Intent(this,LoginActivity.class));finish();
    }
    @Override public void onBackPressed() {
        if(!tab.equals("Home")) switchTab("Home");else super.onBackPressed();
    }
}
