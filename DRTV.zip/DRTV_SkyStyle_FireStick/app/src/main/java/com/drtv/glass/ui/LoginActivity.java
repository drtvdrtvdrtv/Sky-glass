package com.drtv.glass.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.drtv.glass.R;
import com.drtv.glass.api.XtreamClient;
import com.drtv.glass.data.Session;

public final class LoginActivity extends Activity {
    private EditText dns,user,password;
    private LinearLayout panel;
    private CheckBox remember;
    private Button login;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Session.active() || Session.restore(this)) { goHome(); return; }
        LinearLayout outer=U.col(this);outer.setGravity(Gravity.CENTER);
        outer.setBackgroundResource(R.drawable.bg_glass);U.pad(outer,this,20,15,20,15);
        setContentView(outer);
        panel=U.col(this);panel.setGravity(Gravity.CENTER_HORIZONTAL);U.pad(panel,this,42,18,42,18);
        panel.setBackground(U.rounded(0xAA121836,U.dp(this,24)));
        outer.addView(panel,U.lp(560,-2,this));
        panel.addView(U.skyLogo(this,155,86));
        TextView heading=U.text(this,"Welcome to your TV",28,true);
        heading.setGravity(Gravity.CENTER);panel.addView(heading,U.lp(-1,48,this));
        TextView tagline=U.text(this,"Sign in with your IPTV provider details",14,false);
        tagline.setTextColor(U.MUTED);tagline.setGravity(Gravity.CENTER);panel.addView(tagline,U.lp(-1,34,this));
        dns=field("DNS / server URL",false);user=field("Username",false);password=field("Password",true);
        remember=new CheckBox(this);remember.setText("Remember me on this Fire Stick");
        remember.setTextColor(U.WHITE);remember.setButtonTintList(android.content.res.ColorStateList.valueOf(U.LAVENDER));
        remember.setChecked(true);panel.addView(remember,U.lp(-1,48,this));
        status=U.text(this,"",13,false);status.setTextColor(0xFFFFC5CE);
        panel.addView(status,U.lp(-1,25,this));
        login=U.button(this,"Sign in  →",this::authenticate);panel.addView(login,U.lp(250,48,this));
        dns.requestFocus();
    }
    private EditText field(String hint,boolean secret) {
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextColor(U.WHITE);
        input.setHintTextColor(0xFFB4BBD8);input.setTextSize(15);input.setHint(hint);
        input.setInputType(secret ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD :
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        input.setBackground(U.rounded(0xFF29314D,U.dp(this,11)));
        U.pad(input,this,14,0,14,0);
        LinearLayout.LayoutParams p=U.lp(-1,49,this);p.setMargins(0,U.dp(this,8),0,0);
        panel.addView(input,p);
        return input;
    }
    private void authenticate() {
        String host=dns.getText().toString().trim(), u=user.getText().toString().trim(),p=password.getText().toString();
        if(host.isEmpty() || u.isEmpty() || p.isEmpty()) { status.setText("Enter all three login fields.");return; }
        login.setEnabled(false);login.setText("Connecting…");status.setText("Checking your provider…");
        XtreamClient.login(host,u,p,(normalized,error)->{
            if(isFinishing() || isDestroyed()) return;
            login.setEnabled(true);login.setText("Sign in  →");
            if(error!=null) { status.setText(error); return; }
            Session.use(normalized,u,p);
            try { Session.save(this,remember.isChecked()); }
            catch(Exception e) { status.setText("Secure storage unavailable; signed in for this session only."); }
            goHome();
        });
    }
    private void goHome() { startActivity(new Intent(this,HomeActivity.class));finish(); }
}
