package com.drtv.glass.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.drtv.glass.R;
import com.drtv.glass.api.XtreamClient;
import com.drtv.glass.data.Library;
import com.drtv.glass.data.MediaEntry;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

public final class DetailsActivity extends Activity {
    private MediaEntry item;
    private LinearLayout main,information,episodes,actions;
    private Button favourite;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { item=MediaEntry.fromJson(new JSONObject(getIntent().getStringExtra("entry"))); }
        catch(Exception e) { finish();return; }
        LinearLayout root=U.col(this);root.setBackgroundResource(R.drawable.bg_glass);
        U.pad(root,this,36,22,36,25);setContentView(root);
        LinearLayout bar=U.row(this);
        root.addView(bar,U.lp(-1,54,this));
        bar.addView(U.button(this,"‹  Back",this::finish),U.lp(123,47,this));
        TextView brand=U.text(this,"sky  |  "+labelType(item.type),21,true);
        U.pad(brand,this,30,0,0,0);bar.addView(brand);
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        main=U.col(this);scroll.addView(main);
        LinearLayout overview=U.row(this);overview.setGravity(Gravity.TOP);
        main.addView(overview,U.lp(-1,270,this));
        ImageView cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(U.rounded(0xFF28385A,U.dp(this,12)));
        overview.addView(cover,U.lp(235,265,this));ImageLoader.load(cover,item.image);
        LinearLayout right=U.col(this);U.pad(right,this,30,0,0,0);
        overview.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        TextView name=U.text(this,item.title,31,true);name.setMaxLines(3);
        right.addView(name,U.lp(-1,-2,this));
        TextView meta=U.text(this,labelType(item.type)+"  •  Your provider's library",14,false);
        meta.setTextColor(U.MUTED);U.pad(meta,this,0,10,0,8);right.addView(meta);
        actions=U.row(this);U.pad(actions,this,0,8,0,8);right.addView(actions,U.lp(-1,69,this));
        if(!MediaEntry.SERIES.equals(item.type)) actions.addView(U.button(this,"▶  Watch now",()->watch(item)),U.lp(162,47,this));
        favourite=U.button(this,"",()->{
            boolean added=Library.toggleFavourite(this,item);
            favourite.setText(added?"♥  In My List":"♡  Add to My List");
        });
        favourite.setText(Library.isFavourite(this,item)?"♥  In My List":"♡  Add to My List");
        LinearLayout.LayoutParams flp=U.lp(173,47,this);flp.setMargins(U.dp(this,12),0,0,0);
        actions.addView(favourite,flp);
        information=U.col(this);right.addView(information,U.lp(-1,-2,this));
        episodes=U.col(this);main.addView(episodes,U.lp(-1,-2,this));
        if(MediaEntry.LIVE.equals(item.type)) liveGuide();else details();
    }
    private String labelType(String type) {
        return MediaEntry.LIVE.equals(type)?"Live TV":MediaEntry.MOVIE.equals(type)?"Movie":"Series";
    }
    private void append(LinearLayout target,String text,int size,boolean strong) {
        TextView t=U.text(this,text,size,strong);
        t.setTextColor(strong?U.WHITE:U.MUTED);t.setMaxLines(7);
        U.pad(t,this,0,6,0,6);target.addView(t,U.lp(-1,-2,this));
    }
    private void details() {
        append(information,"Loading programme details…",15,false);
        XtreamClient.details(item,(data,error)->{
            if(isFinishing()||isDestroyed())return;
            information.removeAllViews();
            if(error!=null){append(information,"Details unavailable: "+error,14,false);return;}
            JSONObject info=data.optJSONObject("info");
            if(info==null)info=new JSONObject();
            String description=info.optString("plot",data.optString("plot",""));
            String genre=info.optString("genre","");
            String year=info.optString("releasedate",info.optString("releaseDate",""));
            String rating=info.optString("rating", "");
            if(!year.isEmpty() || !genre.isEmpty() || !rating.isEmpty())
                append(information,year+"   "+genre+"   "+rating,14,false);
            if(!description.isEmpty())append(information,description,15,false);
            if(MediaEntry.MOVIE.equals(item.type)) {
                JSONObject movie=data.optJSONObject("movie_data");
                if(movie!=null) {
                    String ext=movie.optString("container_extension","");
                    if(!ext.isEmpty())item.extension=ext;
                }
            } else {
                populateEpisodes(data.optJSONObject("episodes"));
            }
        });
    }
    private void populateEpisodes(JSONObject collection) {
        if(collection==null || collection.length()==0) {
            append(episodes,"No episodes returned by this provider.",16,false);return;
        }
        append(episodes,"Episodes",24,true);
        Iterator<String> seasons=collection.keys();
        while(seasons.hasNext()) {
            String season=seasons.next();
            append(episodes,"Season "+season,19,true);
            JSONArray values=collection.optJSONArray(season);
            if(values==null)continue;
            for(int i=0;i<values.length();i++) {
                JSONObject ep=values.optJSONObject(i);if(ep==null)continue;
                String eid=ep.optString("id","");if(eid.isEmpty())continue;
                String name=ep.optString("title", "Episode "+(i+1));
                String ext=ep.optString("container_extension","mp4");
                MediaEntry video=new MediaEntry(eid,MediaEntry.SERIES,item.title+" · "+name,
                        item.image,item.categoryId,ext);
                Button button=U.button(this,"▶  "+name,()->watch(video));
                button.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams p=U.lp(-1,52,this);p.setMargins(0,U.dp(this,4),0,U.dp(this,4));
                episodes.addView(button,p);
            }
        }
    }
    private static String decode(String value) {
        if(value==null)return "";
        try {return new String(Base64.decode(value,Base64.DEFAULT),StandardCharsets.UTF_8);}
        catch(Exception e){return value;}
    }
    private String time(long seconds) {
        if(seconds==0)return "";
        return new SimpleDateFormat("HH:mm",Locale.UK).format(new Date(seconds*1000));
    }
    private void liveGuide() {
        append(information,"Live channel · Select Watch now to play",15,false);
        append(episodes,"TV Guide · What's on",24,true);
        append(episodes,"Loading upcoming programmes…",15,false);
        XtreamClient.shortEpg(item.id,(schedule,error)->{
            if(isFinishing()||isDestroyed())return;
            episodes.removeAllViews();append(episodes,"TV Guide · What's on",24,true);
            if(error!=null) {append(episodes,"Guide unavailable: "+error,14,false);return;}
            if(schedule==null || schedule.length()==0) {append(episodes,"No guide data provided for this channel.",14,false);return;}
            for(int i=0;i<schedule.length();i++) {
                JSONObject programme=schedule.optJSONObject(i);if(programme==null)continue;
                String name=decode(programme.optString("title","Programme"));
                String description=decode(programme.optString("description",""));
                String from=time(programme.optLong("start_timestamp",0));
                String until=time(programme.optLong("stop_timestamp",0));
                append(episodes,from+" – "+until+"     "+name,18,true);
                if(!description.isEmpty())append(episodes,description,13,false);
            }
        });
    }
    private void watch(MediaEntry video) {
        Intent i=new Intent(this,PlayerActivity.class);
        i.putExtra("entry",video.toJson().toString());startActivity(i);
    }
}
