@echo off
cd /d "%~dp0"
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo Build failed. Open this folder in Android Studio to install the missing SDK or review the error.
  pause
  exit /b 1
)
echo.
echo APK created: app\build\outputs\apk\debug\app-debug.apk
pause
